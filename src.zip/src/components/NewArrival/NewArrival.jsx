import React from 'react';

const NewArrival = () => {
    return (
        <div>
            <h2>this from new arrival.</h2>
        </div>
    );
};

export default NewArrival;